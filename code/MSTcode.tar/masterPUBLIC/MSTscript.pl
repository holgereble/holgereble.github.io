use application "fan";
use application "polytope";


## GLOBAL VARIABLE:
my @edge_linear_forms;


### MAIN METHOD: COMPUTE MST-CONE ###
### MAIN METHOD: COMPUTE MST-CONE ###
### MAIN METHOD: COMPUTE MST-CONE ###

#INPUT @Arg0: $points: Matrix<Rational>, the points of the underlying point configuration. [A]
#INPUT @Arg1: $heights: Vector<Rational>, the realvalued height/lifting function defined on $points. [h]
#INPUT @Arg2: $edges: Array<Set>, the edges of the dual graph. Labels in each Set are wrt. $triangulation.
#INPUT @Arg3: $triangulation: Matrix, the maximal simplices in the regular subdivision wrt. $points.
#INPUT @Arg4: $sc: Cone, the secondary cone of the regular subdivision.
#INPUT @Arg5: @spanning_tree: Array<Set>, a subarray of $edges representing a spanning tree of the dual graph.

sub MST_cone{ #formerly inverse_kruskal
    my ($points, $heights, $edges, $triangulation, $sc, $spanning_tree) = @_;
    @edge_linear_forms=();
    for(my $i=0; $i<$edges->size;++$i){ # get linear form for ALL dual edges
        my $this_edge = $edges->[$i];
        my ($first,$second)=@{$this_edge};
        linearform_fromlabels($points,$heights,$triangulation->[$first],$triangulation->[$second]);# populates @edge_linear_forms, one linear form per edge. order = order of edges
    }
    my @spanningtree_idx = get_spanningtree_idx($spanning_tree, $edges); # Get IDs of $spanning_tree Array<Set> with respect to the whole $edge array.
    my $MSTcone;
    my $MSTcone_is_set=0;
    for(my $i=0; $i<$spanning_tree->size-1; ++$i){# First for-loop in Algorithm 1.
        my $this_edgeID = id_of_edge($spanning_tree->[$i],$edges);
        my $next_edgeID = id_of_edge($spanning_tree->[$i+1],$edges);
        my ($cone,$entirespace, $returnform) = linear_form_cones($points,$sc,$edge_linear_forms[$next_edgeID],$edge_linear_forms[$this_edgeID], $next_edgeID, $this_edgeID);
        if($MSTcone_is_set==0){$MSTcone = $cone; $MSTcone_is_set=1};
        if ($cone){ #if representable
            $MSTcone = intersection($MSTcone,$cone);
        }
        else{return ($sc,0)}# if not representable
    }
    my @rel_indices = relevance_indices($edges, $triangulation, @spanningtree_idx); #See Section 4.
    for (my $k=0; $k<scalar(@rel_indices); ++$k){ # Second for-loop in Algorithm 1 
        next if $rel_indices[$k]==-1; # Then, nothing to do.
        my ($cone,$entirespace, $returnform) = linear_form_cones($points,$sc,$edge_linear_forms[$k],$edge_linear_forms[$rel_indices[$k]], $k, $rel_indices[$k]);
        next if $entirespace==1; # Instable edges. Nothing to do in this case.
        if ($cone){# if representable
            $MSTcone = intersection($MSTcone,$cone)} 
        else{return ($sc,0)}# if not representable
    }
    $MSTcone = intersection($MSTcone,$sc);
    if ($MSTcone->DIM<$sc->DIM){return ($sc,0)} # unnecessary; check for safety reasons
    return ($MSTcone,1);
}

### Compute the edge linear form as in Definition 3.
sub linearform_fromlabels{
    my ($points, $heights, $vert1, $vert2)= @_;
    my ($first_vol, $second_vol)= map{nvol($points->minor($_,All))} ($vert1,$vert2);
    my $lifted_points = new Matrix($points|$heights);
    my $E_h = nvol($lifted_points->minor($vert1+$vert2, All));
    my $L_h = $lifted_points->minor($vert1+$vert2, All);
    my @coeff = (0) x $points->rows;
    my $vertset = $vert1+$vert2;
    my $sign=(-1)**$L_h->cols;
    for (my $j=0; $j<$vertset->size; ++$j){
        my $minor = new Matrix($L_h->minor(~[$j],~[$L_h->cols-1]));
        $coeff[$vertset->[$j]]=det($minor)*$sign;
        $sign = $sign*(-1);	
    }
    push @edge_linear_forms, new Vector(@coeff);
    return @edge_linear_forms;
}

sub get_spanningtree{ # Slice of sub-Array<Set> according to input $ID_set Array<Int>
    my ($edges, $ID_set)=@_;
    return  new Array<Set>(map {$edges->[$_]} @{$ID_set});
}

sub get_spanningtree_idx{
    my ($spanning_tree, $edges)=@_;
    my @idx = ();
    for(my $k=$spanning_tree->size-1; $k>-1; --$k){
        push @idx, id_of_edge($spanning_tree->[$k],$edges);
    }
    return @idx;
}

sub id_of_edge{
    my($crit_edge, $edges)=@_;
    for(my $k=0; $k<$edges->size; ++$k){
        return $k if $crit_edge==$edges->[$k];
    }
}

# implements \{|h(x)|\geq |g(x)|\}
sub linear_form_cones{
    my ($points, $sc, $h, $g, $Redge_ID, $base_edgeID)= @_; # $k and $base_edge are just for trouble shooting
    my @lf_cones=();
    my @linear_forms=();
    my @tmp = ();
    my $cone;
    my @sc_intersection_dimensions = ();
    my $sc_int;
    my $name_base = join("", $Redge_ID, "-",$base_edgeID, "_");
    my $name;

# Implements g >= 0, h >= 0.
    return (new Cone(),1) if ($h-$g) == zero_vector($h->dim);
    push @tmp, $g;
    push @tmp, $h;
    push @tmp, $h-$g if ($h-$g)!= zero_vector($h->dim); # don't add zero vector
    $name = join ("",$name_base, "g+h+");
    $cone = new Cone($name, INEQUALITIES=>new Matrix([@tmp]));
    $sc_int = intersection($cone,$sc);
    push @sc_intersection_dimensions, $sc_int->DIM;
    push @lf_cones, $cone if $sc_int->DIM==$points->rows;
    push @linear_forms, new Matrix([$tmp[2]]) if $sc_int->DIM==$points->rows;
    @tmp=();

# Implements g >= 0, h <= 0.
    return (new Cone(), 1) if ($h+$g) == zero_vector($h->dim);
    push @tmp, $g;
    push @tmp, -$h;
    push @tmp, -($h+$g) if ($h+$g)!= zero_vector($h->dim); # don't add zero vector
    $name = join ("",$name_base, "g+h-");
    $cone = new Cone($name,INEQUALITIES=>new Matrix([@tmp]));
    $sc_int = intersection($cone,$sc);
    push @sc_intersection_dimensions, $sc_int->DIM;
    push @lf_cones, $cone if $sc_int->DIM==$points->rows;
    push @linear_forms, new Matrix([$tmp[2]]) if $sc_int->DIM==$points->rows;
    @tmp=();

# Implements g <= 0, h >= 0.
    return(new Cone(),1) if ($h+$g) == zero_vector($h->dim);
    push @tmp, -$g;
    push @tmp, $h;
    push @tmp, $h+$g if ($h+$g)!= zero_vector($h->dim); # don't add zero vector
    $name = join ("",$name_base, "g-h+");
    $cone = new Cone($name,INEQUALITIES=>new Matrix([@tmp]));
    $sc_int = intersection($cone,$sc);
    push @sc_intersection_dimensions, $sc_int->DIM;
    push @lf_cones, $cone if $sc_int->DIM==$points->rows;
    push @linear_forms, new Matrix([$tmp[2]]) if $sc_int->DIM==$points->rows;
    @tmp=();

# Implements g <= 0, h <= 0.
    return(new Cone(),1) if ($g-$h) == zero_vector($h->dim);
    push @tmp, -$g;
    push @tmp, -$h;
    push @tmp, $g-$h if ($g-$h)!= zero_vector($h->dim); # don't add zero vector
    $name = join ("",$name_base, "g-h-");
    $cone = new Cone($name,INEQUALITIES=>new Matrix([@tmp]));
    $sc_int = intersection($cone,$sc);
    push @sc_intersection_dimensions, $sc_int->DIM;
    push @lf_cones, $cone if $sc_int->DIM==$points->rows;
    push @linear_forms, new Matrix([$tmp[2]]) if $sc_int->DIM==$points->rows;
    @tmp=();

    if (scalar(@lf_cones)==0){
        print "boundary facet. base_edgeID: $base_edgeID, R_edgeID: $Redge_ID  \n";
        return ();
    }
    my $returncone = $lf_cones[0];
    my $form_matrix = $linear_forms[0];
    my $returnform = new Vector($form_matrix->row(0));    
    die "lf_cones has more than one entry" if scalar(@lf_cones)>1; # By Propopsition 12, @lf_cones must not have more than one entry.
    return ($returncone,0, $returnform);
}

sub relevance_indices{
    my($edges, $triangulation, @spanningtree_idx) = @_;
    my @rel_indices = (0) x $edges->size;
    my $subtree = new Set();
    my $relevant = new Set(0..$edges->size-1);
    for(my $i=$#spanningtree_idx; $i>-1; --$i){
        my $edgeID = $spanningtree_idx[$i];
        $rel_indices[$edgeID]=-1;
        $subtree->collect($edgeID);
        my $new_relevant = relevant_edges($edges,$edgeID,$subtree, $triangulation);
        my $diff = $relevant-$new_relevant-new Set($edgeID);
        foreach my $item (@{$diff}){
            $rel_indices[$item]=$spanningtree_idx[$i];
        }
        $relevant = $new_relevant;
    }
    return @rel_indices;
}

sub relevant_edges{
    my ($edges,$crit_edge,$subtree, $triangulation)=@_;
    my $all_edges = new Set(0..$edges->size-1);
    my $closing = closing_circuits($edges, $subtree,$triangulation);
    my $relevant = $all_edges - $subtree - $closing;#index level
        return $relevant;
}

sub closing_circuits{
    my ($edges, $subtree,$triangulation)=@_;
    my @enlarged_tree = ();
    my $circuitclosing_edges = new Set();
    for(my $i=0; $i<$triangulation->rows; ++$i){
        push @{$enlarged_tree[$i]},();
    }
    for (my $i=0; $i<$subtree->size; ++$i){
        my $edge = $edges->[$subtree->[$i]];
        push @{$enlarged_tree[$edge->back]},$edge->front;
        push @{$enlarged_tree[$edge->front]},$edge->back;
    }
    my $inc = new IncidenceMatrix([@enlarged_tree]);
    for(my $i=0; $i<$edges->size;++$i){
        next if $subtree->contains($i);
        my @copy = map { [@$_] } @enlarged_tree;
        if(creates_circuit($edges->[$i]->front,$edges->[$i]->back,@copy)){
            $circuitclosing_edges = $circuitclosing_edges + $i;
        }
    }
    return $circuitclosing_edges;
}

sub creates_circuit{
    my ($front,$back,@enlarged_tree)=@_;
    push @{$enlarged_tree[$front]},$back;
    push @{$enlarged_tree[$back]},$front;
    my $enlarged =  new IncidenceMatrix([@enlarged_tree]);
    my $new_tree =  new graph::Graph<Undirected>(ADJACENCY=>$enlarged);
    my $matroid = matroid::matroid_from_graph($new_tree);
    if($matroid->CIRCUITS->size > 0){
        return  1;
    }
    return 0;
}


####### COMPUTE TROPICALLY WEIGHTED  DUAL GRAPH ######
####### COMPUTE TROPICALLY WEIGHTED  DUAL GRAPH ######
####### COMPUTE TROPICALLY WEIGHTED  DUAL GRAPH ######

### INPUT @Arg0: Matrix<Rational>, the points A of the underlying point configuration.
### INPUT @Arg1: Vector<Rational>, the height function h..
### OUTPUT @Out0: Tropical edge weights ordered from small to big
### OUTPUT @Out1: Array<Set> as edges according to the order of @Out0.
### OUTPUT @Out2: The maximal cells according to which the edges of @Out1 are given.
### OUTPUT @Out3: The secondary cone of the regular subdivision.  

sub get_trop_weighted_dual_graph{
    my ($points, $heights) = @_;
    my $sop = new fan::SubdivisionOfPoints(POINTS=>$points, WEIGHTS=>$heights);
    my $sc = $sop->secondary_cone();
    my $maximal_cells = $sop->MAXIMAL_CELLS;
    my $tropical_edge_weights = tropical_edge_weights($points, $heights, $maximal_cells);
    my @evals =();
    my @edges = ();
    for (my $j=0; $j< $tropical_edge_weights->size(); ++$j) {
        push @evals, $tropical_edge_weights->[$j]->first;
        push @edges, $tropical_edge_weights->[$j]->second;
    }
    return (new Array<Float>([@evals]),new Array<Set<Int>>([@edges]), $maximal_cells, $sc);
}

sub tropical_edge_weights{
    my ($points, $heights, $triangulation) = @_;
    my $complex = new topaz::SimplicialComplex(FACETS=>rows($triangulation));
    my $dual_edges = new Array<Set>($complex->DUAL_GRAPH->EDGES);
    my @epi = ();
    for (my $i=0; $i<$dual_edges->size(); ++$i) {
        my $this_edge=$dual_edges->[$i];
        my ($first,$second)=@{$this_edge};
        my $val = trop_fromlabels($triangulation->[$first], $triangulation->[$second],$points, $heights);
        my $this_pair = new Pair< Float, Set<Int>>($val,$this_edge);
        push @epi, $this_pair;
    }
    my @sorted_epi = sort  {$a->[0]<=>$b->[0]}  @epi;
    #my @sorted_epi = sort  {$b->[0]<=>$a->[0]}  @epi; # variant for maximum spanning trees
    my $epi = new Array< Pair< Float, Set<Int> >> ([@sorted_epi]);
    return $epi;
}

sub trop_fromlabels{
    my ($vert1, $vert2, $points, $heights)= @_;
    my $lifted_points = new Matrix($points|$heights);
    return nvol($lifted_points->minor($vert1+$vert2, All));
}

sub nvol{
    my $simplex = $_[0];
    if ($simplex->rows!=$simplex->cols){print STDOUT "Not a triangulation \n";return -1;}
    return abs(det($simplex));
}

### GET TROPICALLY WEIGHTED MST ###
### GET TROPICALLY WEIGHTED MST ###
### GET TROPICALLY WEIGHTED MST ###
#As byproduct, one obtaines the associated phylogenetic tree. 

# Computes the order of the outer nodes of the binary tree that arises from merging maximal 
# cells along the dual edges, ordered by ascending epistatic weight. 
# The chosen unique order is induced by the lex-order of the node sets of binary trees being merged. 
# As a byproduct we get the critical edges of the filtration, a.k.a the edges of the MST.
# At any stage, the forest is stored in the variable @partition.
sub get_trop_MST{
    my ($trop_weight, $edges, $triangulation) = @_;
    my @ind = map {$_} 0..($triangulation->rows-1);
    my ($ind_ref,$partition_ref);
    my @partition =();
    my @crit_edges =();
    for (my $i=0;$i<$triangulation->rows;++$i){push @{$partition[$i]}, $i;}
    for (my $i=0; $i<$edges->size(); ++$i) {
        my ($first,$second)=@{$edges->[$i]};
        my ($lo,$hi)=($ind[$first],$ind[$second]);# encodes the partition
            if ($hi != $lo){
                push @crit_edges, $i;
                if ($lo>$hi) { my $tmp=$lo; $lo=$hi; $hi=$tmp; }
                if(clusterset($triangulation, $partition[$lo])<clusterset($triangulation, $partition[$hi])){# lex-order determines merging order
                    ($ind_ref,$partition_ref) = merge_bintrees($lo,$hi,\@ind,\@partition);
                }
                else{
                    ($ind_ref,$partition_ref) = merge_bintrees($hi,$lo,\@ind,\@partition);
                }
                @ind = @{$ind_ref};
                @partition = @{$partition_ref};
            }
    }
    for(my $i=0;$i<scalar(@partition);++$i){
        if(scalar(@{$partition[$i]})>0){
            #return (new Array<Int>([@{$partition[$i]}]), new Array<Int>([@crit_edges])); # @partition represents the associated phylogenetic tree.
            return new Array<Int>([@crit_edges]);
        }
    }
}
sub merge_bintrees{
    my ($a, $b, $ind_ref, $partition_ref) = @_;
    my @ind = @{$ind_ref};
    my @partition = @{$partition_ref};
    push @{$partition[$a]}, @{$partition[$b]}; #merge tree $b on the right of tree $a
        @{$partition[$b]} = ();
    for (my $k=0; $k<scalar(@ind); ++$k) {
        if($ind[$k]==$b){$ind[$k]=$a;}
    }
    return (\@ind,\@partition);
}

sub clusterset{
    my ($triang, $partitionset_ref)=@_;
    my @resultset = ();
    my @partitionset = @{$partitionset_ref};
    for(my $i=0; $i<scalar(@partitionset); ++$i){
        push @resultset, @{$triang->[$partitionset[$i]]}
    }
    return new Set([@resultset]);
}




