use application "fan";
use application "polytope";
use Time::HiRes qw( time );

script("MSTscript.pl");

my $start_time = Time::HiRes::gettimeofday();

my $poly = cube(3);
my $points = $poly->VERTICES;
my $heights = new Vector(7,3,7,4,1,3,9,7); #random vector;

my ($evals, $edges, $triangulation, $sc) = get_trop_weighted_dual_graph($points, $heights);
my $crit_edges = get_trop_MST($evals,$edges, $triangulation); # returns edge IDs.
my $MST = get_spanningtree($edges, $crit_edges); # return Array<Set>
MST_cone($points, $heights,$edges, $triangulation, $sc, $MST);

my $stop_time = Time::HiRes::gettimeofday();

print "\nIt took ", sprintf("%.2f", $stop_time - $start_time),  " seconds\n\n";
